@extends('layouts.layout_01')

@section('title','Home')

@section('style_css')

@stop

@section('content')

@stop

@section('script_js')

@stop
