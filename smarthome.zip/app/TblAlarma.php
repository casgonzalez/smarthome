<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TblAlarma extends Model
{
    //
}
