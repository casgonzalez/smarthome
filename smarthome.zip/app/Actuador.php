<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Actuador extends Model
{

    protected $table = 'actuators';
}
