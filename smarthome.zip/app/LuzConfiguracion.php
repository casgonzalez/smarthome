<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LuzConfiguracion extends Model
{
    //
}
