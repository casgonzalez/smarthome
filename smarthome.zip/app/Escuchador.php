<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Escuchador extends Model
{

    protected $table = 'escuchadores';
}
