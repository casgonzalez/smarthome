<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8    ">
            <div class="card mb-5">
                <div class="card-header">
                    <span>Todas las notificaciones (<?php echo e($nts->count()); ?>)</span>
                </div>
                <div class="card-body overflor-y" style="height: 500px;">
                    <?php $__currentLoopData = $nts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="dropdown-item" href="<?php echo e(asset('perfil')); ?>">
                            <?php switch($nt->idActuador):
                                case (1): ?>
                                <img src="<?php echo e(asset('imagenes/actuadores/luz-prendida.png')); ?>" style="width: 20px; height: 20px; border-radius: 100%;" alt="">
                                <?php break; ?>
                                <?php case (2): ?>
                                <img src="<?php echo e(asset('imagenes/actuadores/luz-prendida.png')); ?>" style="width: 20px; height: 20px; border-radius: 100%;" alt="">
                                <?php break; ?>
                                <?php case (3): ?>
                                <img src="<?php echo e(asset('imagenes/actuadores/luz-prendida.png')); ?>" style="width: 20px; height: 20px; border-radius: 100%;" alt="">
                                <?php break; ?>
                                <?php case (4): ?>
                                <img src="<?php echo e(asset('imagenes/actuadores/ventilador-prendido.png')); ?>" style="width: 20px; height: 20px; border-radius: 100%;" alt="">
                                <?php break; ?>
                                <?php case (5): ?>
                                <img src="<?php echo e(asset('imagenes/actuadores/aire-apagado.png')); ?>" style="width: 20px; height: 20px; border-radius: 100%;" alt="">
                                <?php break; ?>
                                <?php case (6): ?>
                                <img src="<?php echo e(asset('imagenes/actuadores/candado-apagado.png')); ?>" style="width: 20px; height: 20px; border-radius: 100%;" alt="">
                                <?php break; ?>
                            <?php endswitch; ?>
                            <?php echo e($nt->actuator); ?>

                            <?php switch($nt->state):
                                case (0): ?>
                                <?php if($nt->actuator == 'Porton'): ?>  Se cerro <?php else: ?> Se apago <?php endif; ?>
                                <?php break; ?>
                                <?php case (1): ?>
                                <?php if($nt->actuator == 'Porton'): ?>  Se abrio <?php else: ?> Se cerro <?php endif; ?>
                                <?php break; ?>
                            <?php endswitch; ?>

                            (<?php echo e($nt->nombre); ?> ) <br>
                            <?php echo e($nt->created_at); ?> <br>
                                <form action="">
                                    <button class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> Eliminar</button>
                                </form>
                        </a>
                        <div class="divider"></div>
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_01', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyectos\smarthome\resources\views/nts.blade.php ENDPATH**/ ?>