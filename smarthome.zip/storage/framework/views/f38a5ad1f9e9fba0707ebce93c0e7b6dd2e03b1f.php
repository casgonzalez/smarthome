<div class="row">
    <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
        <div class="form-group">
            <label for="">Nombre Completo</label>
            <input type="text" <?php if($profile): ?> disabled <?php endif; ?> value="<?php echo e($user->nombre); ?>" class="form-control form-control-lg" name="nombre">
        </div>
    </div>
    <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
        <div class="form-group">
            <label for="">Email</label>
            <input type="email" <?php if($profile): ?> disabled <?php endif; ?> value="<?php echo e($user->email); ?>" class="form-control-lg form-control" name="email">
        </div>
    </div>
    <?php if($profile == false): ?>
    <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
        <div class="form-group">
            <label for="">Contraseña</label>
            <input type="password" <?php if($profile): ?> disabled <?php endif; ?> class="form-control form-control-lg" name="password">
        </div>
    </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Jesus\Documents\Meli(♥)\smarthome\resources\views/administracion/usuarios/form.blade.php ENDPATH**/ ?>