<span id="rangeIluminacion"><?php echo e($actuador->configuracion); ?></span>
<input type="range" id="rangoIluminacion" name="configuracion" value='<?php echo e($actuador->configuracion); ?>' min="1" max="3"  autocomplete="off">
<br>
<span class="text--btm">Iluminación (<?php echo e($actuador->configuracion); ?>)</span>
<br>
<button class="btn btn-primary btn-sm form-control" style="width: 30%; margin: auto;" type="submit">
    <i class="fas fa-check"></i>
</button>
<?php /**PATH C:\Users\Jesus\Documents\Meli(♥)\smarthome\resources\views/actuadores/iluminacion.blade.php ENDPATH**/ ?>