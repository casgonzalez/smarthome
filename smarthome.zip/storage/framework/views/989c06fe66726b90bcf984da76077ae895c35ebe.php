<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tu puerta ha sido forzada</title>
</head>
<body>

    <h3>Hola <?php echo e($userAdmin->nombre); ?> te informamos que tu puerta ha sido forzada, Fecha: <?php echo e($fecha); ?></h3>

</body>
</html>
<?php /**PATH C:\proyectos\smarthome\resources\views/mails/forzar_puerta.blade.php ENDPATH**/ ?>