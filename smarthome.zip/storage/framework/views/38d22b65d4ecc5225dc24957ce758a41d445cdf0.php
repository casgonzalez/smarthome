<?php if($actuador->id == 1 && $actuador->estado == 1): ?>
    <?php echo $__env->make('actuadores.iluminacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if($actuador->id == 2 && $actuador->estado == 1): ?>
    <?php echo $__env->make('actuadores.ventilador', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Jesus\Documents\Meli(♥)\smarthome\resources\views/actuadores/configurador.blade.php ENDPATH**/ ?>