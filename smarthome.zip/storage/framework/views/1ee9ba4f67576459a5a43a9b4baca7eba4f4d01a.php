<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Smart Home | <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="icon" href="<?php echo e(asset('imagenes/icons/045-smart home.png')); ?>">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/mdb.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

    <?php echo $__env->yieldContent('style_css'); ?>
</head>
<body class="">
    <header id="header" class="mb-5">
        <nav class="navbar fixed-top navbar-expand-lg navbar-dark mdb-color darken-3 scrolling-navbar">
            <div class="container">
                <a class="navbar-brand text-uppercase" href="<?php echo e(asset('/')); ?>">
                    <img src="<?php echo e(asset('imagenes/icons/011-sensor.png')); ?>" class="logo-avatar" alt="">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">

                    </ul>
                    <ul class="navbar-nav nav-flex-icons">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item <?php echo e(request()->is('administracion') ? 'active' : ''); ?>">
                                <a class="nav-link" href="/">
                                    <i class="fas fa-home"></i> Inicio <span class="sr-only">(current)</span>
                                </a>
                            </li>
                            <?php if(Auth::user()->isAdmin()): ?>
                                <li class="nav-item <?php echo e(request()->is('administracion/usuarios*') ? 'active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(asset('/administracion/usuarios')); ?>">
                                        <i class="fas fa-users"></i>
                                        Usuarios
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if(Auth::user()->isAdmin()): ?>
                            <li class="nav-item  dropdown">
                                <a class="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#">
                                    <i class="fas fa-bell"></i>
                                    <span class="badge badge-danger nt" id="notificacionCount"><?php echo e($notificaciones->count()); ?></span>
                                    Notificaciones
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="height: 300px; overflow-y: scroll;">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <span class="" style="padding: 10px 10px;">Notificaciones</span> <br>
                                            <a href="<?php echo e(asset('notificaciones')); ?>" style="padding: 0px 10px"><small>Ver todo</small></a>
                                        </div>

                                        <span  class="fas fa-trash" style="padding: 10px 10px; cursor: pointer"></span>
                                    </div>

                                    <?php $__currentLoopData = $notificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="dropdown-item" href="<?php echo e(asset('perfil')); ?>">
                                            <?php switch($nt->idActuador):
                                                case (1): ?>
                                                    <img src="<?php echo e(asset('imagenes/actuadores/luz-prendida.png')); ?>" style="width: 20px; height: 20px; border-radius: 100%;" alt="">
                                                <?php break; ?>
                                                <?php case (2): ?>
                                                    <img src="<?php echo e(asset('imagenes/actuadores/luz-prendida.png')); ?>" style="width: 20px; height: 20px; border-radius: 100%;" alt="">
                                                <?php break; ?>
                                                <?php case (3): ?>
                                                    <img src="<?php echo e(asset('imagenes/actuadores/luz-prendida.png')); ?>" style="width: 20px; height: 20px; border-radius: 100%;" alt="">
                                                <?php break; ?>
                                                <?php case (4): ?>
                                                    <img src="<?php echo e(asset('imagenes/actuadores/ventilador-prendido.png')); ?>" style="width: 20px; height: 20px; border-radius: 100%;" alt="">
                                                <?php break; ?>
                                                <?php case (5): ?>
                                                    <img src="<?php echo e(asset('imagenes/actuadores/aire-apagado.png')); ?>" style="width: 20px; height: 20px; border-radius: 100%;" alt="">
                                                <?php break; ?>
                                                <?php case (6): ?>
                                                    <img src="<?php echo e(asset('imagenes/actuadores/candado-apagado.png')); ?>" style="width: 20px; height: 20px; border-radius: 100%;" alt="">
                                                <?php break; ?>
                                            <?php endswitch; ?>
                                            <?php echo e($nt->actuator); ?>

                                            <?php switch($nt->state):
                                                case (0): ?>
                                                    <?php if($nt->actuator == 'Porton'): ?>  Se cerro <?php else: ?> Se apago <?php endif; ?>
                                                <?php break; ?>
                                                <?php case (1): ?>
                                                    <?php if($nt->actuator == 'Porton'): ?>  Se abrio <?php else: ?> Se cerro <?php endif; ?>
                                                <?php break; ?>
                                            <?php endswitch; ?>

                                            (<?php echo e($nt->nombre); ?> ) <br>
                                            <?php echo e($nt->created_at); ?>

                                        </a>
                                        <div class="divider"></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </li>
                            <?php endif; ?>
                            <li class="nav-item  dropdown ">
                                <a class="nav-link  dropdown-toggle" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#">
                                    <?php echo e(Auth::user()->nombre); ?>

                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(asset('perfil')); ?>">Perfil</a>
                                    <a class="dropdown-item" href="<?php echo e(asset('/')); ?>">Mi Casa</a>
                                    <div class="dropdown-divider"></div>
                                    <form action="<?php echo e(asset('logout')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button class="dropdown-item" type="submit">Salir</button>
                                    </form>
                                </div>
                            </li>
                        </ul>
                    </ul>
                </div>
            </div>

        </nav>
    </header>

    <div class="space__header"></div>



    <?php echo $__env->yieldContent('content'); ?>



    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('js/mdb.js')); ?>"></script>


    <?php echo $__env->yieldContent('script_js'); ?>
</body>
</html>
<?php /**PATH C:\proyectos\smarthome\resources\views/layouts/layout_01.blade.php ENDPATH**/ ?>