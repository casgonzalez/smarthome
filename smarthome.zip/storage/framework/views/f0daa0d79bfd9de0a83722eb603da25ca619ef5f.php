<div class="row">
    <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
        <div class="form-group">
            <label for="">Nombre Completo</label>
            <input type="text" required <?php if($profile): ?> disabled <?php endif; ?> value="<?php echo e($user->nombre == null ? old('nombre') : $user->nombre); ?>" class="form-control form-control-lg" name="nombre">
            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
        <div class="form-group">
            <label for="">Email</label>
            <input type="email" required <?php if($profile): ?> disabled <?php endif; ?> value="<?php echo e($user->email == null ? old('email') : $user->email); ?>" class="form-control-lg form-control" name="email">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <?php if($profile == false): ?>
    <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
        <div class="form-group">
            <label for="">Contraseña</label>
            <input type="password" min="8"  <?php if($profile): ?> disabled <?php endif; ?> class="form-control form-control-lg" name="password">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\proyectos\smarthome\resources\views/administracion/usuarios/form.blade.php ENDPATH**/ ?>