

<?php $__env->startSection('title','Home'); ?>



<?php $__env->startSection('content'); ?>
    <div class="space__header"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-xs-12 col-sm-12">

                        <form action="<?php echo e(asset('administracion/usuarios')); ?>" method="GET">
                            <div class="input-group input-group-lg box-gray">
                                <input type="text" name="like" value="<?php echo e($like); ?>" placeholder="Buscar usuario..." class="form-control form-control-lg " aria-label="Text input with dropdown button">
                                <div class="input-group-append">
                                    <button class="btn btn-default btn-md m-0 px-3 py-2 z-depth-0" type="submit">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                        </form>

                    </div>
                    <div class="col-lg-4 col-md-4 col-xs-12 col-sm-12">
                        <div class="box-gray text-center">
                            <a href="#" data-toggle="modal" data-target=".bd-example-modal-lg" class="btn btn-default">
                                <i class="fas fa-user-plus"></i>
                                Nuevo
                            </a>
                        </div>
                    </div>
                </div>
                <form action="<?php echo e(asset('administracion/usuarios')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('administracion.usuarios.modal_create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </form>
            </div>
        </div>
        <div class="space__50"></div>
        <div class="row">
            <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th></th>
                            <th>Nombre</th>
                            <th>Correo</th>
                            <th>Estatus</th>
                            <th>Acciones</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="tr-users">
                                    <td>
                                        <img
                                            class="avatar"
                                            style="border-radius: 100%; cursor: pointer"
                                            src="<?php echo e(asset($user->urlFotoPerfil)); ?>" alt="">
                                    </td>
                                    <td>
                                        <?php echo e($user->nombre); ?>

                                    </td>
                                    <td>
                                        <?php echo e($user->email); ?>

                                    </td>
                                    <td>
                                        <span class="badge p-2 text-uppercase <?php echo e($user->eliminado); ?>"><?php echo e($user->eliminado); ?></span>
                                    </td>
                                    <td>
                                        <a href="#" data-toggle="modal" data-target=".bd-example-modal-lg-<?php echo e($user->idUsuario); ?>" class="btn btn-primary btn-sm">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(asset('administracion/usuarios/'.$user->idUsuario)); ?>" style="display: inline-block;" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button  class="btn btn-sm <?php if($user->eliminado == 'activo'): ?> inactivo <?php else: ?> activo <?php endif; ?>">
                                                <i class="fas   <?php if($user->eliminado == 'activo'): ?> fa-trash <?php else: ?> fa-check <?php endif; ?>"></i>
                                            </button>
                                        </form>

                                    </td>
                                </tr>
                                <form action="<?php echo e(asset('administracion/usuarios/'.$user->idUsuario)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <?php echo $__env->make('administracion.usuarios.modal_edit',['idUser'=>$user->idUsuario], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="paginacion__usuarios">
                    <?php echo e($users->links()); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout_01', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jesus\Documents\Meli(♥)\smarthome\resources\views/administracion/usuarios/index.blade.php ENDPATH**/ ?>