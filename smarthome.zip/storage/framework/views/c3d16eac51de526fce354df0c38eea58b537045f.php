<label class="material-switch">

    <input
        <?php if($actuador->estado == 1): ?> checked <?php endif; ?>
        name="estado"
        type="checkbox"
        onchange="changeState('<?php echo e($actuador->id); ?>')"
        class="material-switch-toggle">

    <span class="material-switch-btn"></span>

</label>
<?php /**PATH C:\Users\Jesus\Documents\Meli(♥)\smarthome\resources\views/actuadores/switch.blade.php ENDPATH**/ ?>